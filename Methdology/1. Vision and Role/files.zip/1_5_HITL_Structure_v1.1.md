---
title: 1.5 Human-in-the-Loop 구조
project: Standard Framework Project
phase: Phase 1. Vision & Role 정의
document_id: "1.5 HITL Structure.docx"
version: v1.0
author: KY Song
classification: CONFIDENTIAL

The EAOS methodology defines a structured lifecycle for
Designing, deploying, and governing enterprise-grade AI systems
---
# Project: Standard Framework Project
## 1.5  Human-in-the-Loop 구조
### Phase: 1. Vision & Role 정의
#### [산출물 ID: 1.5 HITL Structure.docx]

- WBS Task
- 1.5.1 HITL 3가지 패턴 정의 (Pre-approval / On-risk / Post-review)
- 1.5.2 Decision Gate 구조 및 통과/거부/타임아웃 처리
- 1.5.3 Human Override 발동 조건 및 절차
- 1.5.4 Agent 별 HITL 적용 기준
- 1.5.5 Approval Gate 코드 구현 기준

| 문서 번호 | 1.5 HITL Structure.docx    |
|-------|----------------------------|
| 버전    | v1.0                       |
| 작성일   | 2026                       |
| 작성자   | KY Song                    |
| 분류    | CONFIDENTIAL               |
| 적용 대상 | Standard Framework 프로젝트 전체 |

# 1. 개요

Human-in-the-Loop(HITL)는 AI Agent의 의사결정 과정에 인간이 직접 개입하여 검토·승인함으로써 책임성과 안전성을 확보하는 구조다. 본 문서는 기존 Authority Model(1.4)과 R&R Matrix(1.3)에서 'Human 승인 필수'로 정의된 항목들의 구체적인 동작 방식을 정의한다.

> 💡 Authority Model이 '어디서 승인받는지'를 정의했다면, HITL 구조는 '어떻게 승인받는지'를 정의한다. Phase 3 ApprovalGate 코드 구현의 직접 기준이 된다.

## 1.1  기존 산출물과의 관계

| 산출물                 | HITL 관련 정의 범위                                     | 1.5에서 추가 정의             |
|---------------------|---------------------------------------------------|-------------------------|
| 1.3 R&R Matrix      | 어떤 Activity에 Human 승인 필요                          | 승인 방식 및 처리 흐름 상세화       |
| 1.4 Authority Model | Agent별 Human Gate 위치                              | Gate 통과/거부/타임아웃 동작 정의   |
| 1.6 Charter 제5조     | Human Override 원칙 선언                              | Override 발동 조건 및 절차 구체화 |
| governance.json     | human_checkpoint: on_risk 정의 (Phase 1 완료 후 생성 예정) | 3가지 패턴 분류 및 코드 구현 기준    |

# 2. HITL 3가지 패턴

본 프로젝트의 모든 Human 개입은 다음 3가지 패턴 중 하나로 분류된다.

| 패턴  | 명칭           | 정의                                  | 적용 시점       | 적용 Agent                |
|-----|--------------|-------------------------------------|-------------|-------------------------|
| P1  | Pre-approval | AI 실행 전 Human이 먼저 승인해야 진행 가능        | 실행 전        | Orch, Back-A, Evol-A    |
| P2  | On-risk      | 실행 중 Risk 기준 초과 시 Human에게 즉시 에스컬레이션 | 실행 중 이상 감지  | Orch, Monitor-A, Back-A |
| P3  | Post-review  | AI 실행 완료 후 Human이 결과를 검토하고 최종 확정    | 실행 후 산출물 확정 | UIUX-A, Front-A, Test-A |

## 2.1 P1  Pre-approval

AI가 실행하기 전에 Human이 반드시 승인해야 한다. 미승인 시 Agent는 대기 상태로 유지된다.

**적용 대상**

| Agent           | 적용 상황                   | 승인 주체                                     |
|-----------------|-------------------------|-------------------------------------------|
| Orch            | Decision Gate 진입 시      | Business Owner 또는 AI Architect            |
| Back-A          | DB 스키마 변경 / 외부 API 연동   | AI Architect + Back-H (Backend Developer) |
| Evol-A          | Context 수정 제안 제출 시      | Governance Board                          |
| Orch (Level 변경) | Authority Level 변경 요청 시 | Governance Board                          |

**처리 흐름**

| ①  Agent 실행 요청  Agent가 작업 시작 전 ApprovalGate 호출        |
|-------------------------------------------------------|
| ②  승인 요청 생성  approval_requests 테이블 INSERT + 담당자 알림 발송 |
| ③  Human 검토  승인자가 요청 내용 확인 (SLA: 업무일 기준 24시간)         |
| ✅  승인  Agent 실행 재개 + audit_logs APPROVED 기록           |
| ❌  거부  Agent 실행 취소 + 거부 사유 audit_logs 기록 + 요청자 알림     |
| ⏰  타임아웃 (24h 초과)  자동 에스컬레이션 → 상위 승인자에게 재전달 + Orch 알림  |

## 2.2 P2  On-risk

실행 중 Risk Threshold 초과 또는 이상 감지 시 즉시 실행을 중단하고 Human에게 에스컬레이션한다.

**트리거 조건**

| 트리거                      | 감지 주체            | 즉각 조치                                       |
|--------------------------|------------------|---------------------------------------------|
| Risk Level CRITICAL 감지   | Orch / Monitor-A | 즉시 실행 중단 → Business Owner 알림 → 긴급 대응        |
| Risk Level HIGH + 미승인 실행 | Orch             | 실행 차단 → Human 승인 게이트 재진입                    |
| KPI Threshold 초과         | Monitor-A        | Incident 알림 → Orch 에스컬레이션 → AI Architect 검토 |
| Drift 감지                 | Monitor-A        | 알림 발송 → Orch → Evol-A 제안 프로세스 시작            |
| Scope 초과 시도              | Orch             | 즉시 차단 → 예외 승인 절차 → audit_logs 기록            |
| Audit Log 실패             | Back-A / Orch    | 배포 차단 → 로그 구현 의무 → 재심사                      |

**처리 흐름**

| ①  이상 감지  Monitor-A 또는 Agent 자체 Risk 체크에서 Threshold 초과     |
|------------------------------------------------------------|
| ②  즉시 실행 중단  진행 중인 작업 안전하게 중단 + 중단 지점 snapshot 저장          |
| ③  Orch 에스컬레이션  Orchestrator에 사유 + 컨텍스트 전달                 |
| ④  Human 알림  담당 Human에게 Incident 내용 즉시 통보 (SLA: 1시간)       |
| ✅  Human 조치 후 재개  Human이 원인 확인 및 조치 완료 → 재개 승인 → Agent 재시작 |
| 🔁  미해결 시 롤백  Human 조치 불가 판단 시 이전 안정 상태로 롤백                 |

## 2.3 P3 Post-review

AI가 작업을 완료한 후 Human이 결과를 검토하고 최종 확정한다. 미확정 산출물은 배포/적용 불가.

**적용 대상**

| Agent   | 검토 대상 산출물                   | 검토 주체                           |
|---------|-----------------------------|---------------------------------|
| UIUX-A  | Persona 분석 결과 / Scenario 초안 | UX Designer (UIUX-H)            |
| Front-A | React 컴포넌트 코드               | Frontend Developer (Front-H)    |
| Back-A  | API / Agent 코드              | Backend Developer (Back-H)      |
| Test-A  | Evaluation Report / KPI 결과  | QA Engineer (Test-H)            |
| Evol-A  | Context 수정 제안서              | AI Architect + Governance Board |

**처리 흐름**

| ①  Agent 작업 완료  산출물 생성 완료 + trajectory_logs 기록         |
|--------------------------------------------------------|
| ②  검토 요청 생성  review_requests 테이블 INSERT + 검토자 알림       |
| ③  Human 검토  검토자가 산출물 확인 (SLA: 업무일 기준 48시간)            |
| ✅  확정 (Confirm)  산출물 상태 CONFIRMED → 배포/적용 가능 상태로 전환    |
| 🔄  수정 요청 (Revise)  수정 사항 명시 → Agent 재작업 → 검토 재시작       |
| ❌  거부 (Reject)  산출물 폐기 + 사유 기록 + Orch 알림 + 재설계 여부 결정   |
| ⏰  타임아웃 (48h 초과)  자동 리마인더 → 추가 24h 후에도 미검토 시 PM 에스컬레이션 |

# 3. Human Override

Human Override는 어떠한 상황에서도 인간이 AI Agent의 실행을 즉시 중단하거나 변경할 수 있는 최우선 권한이다. AI 시스템은 Override를 방해하거나 우회할 수 없다.

> ⚠️  Human Override는 어떠한 자동화 로직도 막을 수 없다. Override 발동 시 모든 Agent는 즉시 응답해야 한다.

## 3.1  Override 발동 조건

| 발동 조건             | 발동 주체                   | 즉각 효과                     |
|-------------------|-------------------------|---------------------------|
| AI 출력이 명백히 잘못된 경우 | 모든 Human 참여자            | 해당 Agent 즉시 중단 + 결과 폐기    |
| 예상치 못한 부작용 발생     | PM / AI Architect       | 관련 Agent 전체 중단 + Rollback |
| 보안 위협 감지          | Compliance Officer      | 전체 시스템 격리 + 보안 감사         |
| 규제 위반 가능성 감지      | Compliance Officer / PM | 즉시 중단 + 법무 검토 요청          |
| Human의 직관적 판단     | 모든 Human 참여자            | 즉시 중단 (사유 설명 불필요)         |

## 3.2  Override 처리 절차

| ①  Override 발동  Human이 Override 명령 실행 (UI 버튼 또는 API 직접 호출)         |
|--------------------------------------------------------------------|
| ②  전체 Agent 즉시 중단  Orchestrator가 모든 실행 중인 Agent에 STOP 신호 전파 (3초 내) |
| ③  상태 Snapshot 저장  중단 시점의 Context, 실행 상태, 입출력 데이터 보존               |
| ④  audit_logs 기록  OVERRIDE 이벤트 기록: 발동자, 시각, 사유, 영향 Agent 목록        |
| ⑤  Human 조치  PM / Architect가 원인 분석 및 조치 방향 결정                      |
| ⑥  재개 또는 롤백 결정  조치 완료 후 재개 승인 OR 이전 안정 상태로 롤백                      |
| ⑦  Governance 보고  Override 발생 사실을 24h 내 Governance Board에 보고       |

# 4. Agent별 HITL 적용 기준

| Agent     | P1 Pre | P2 On-risk | P3 Post | 비고                                                                               |
|-----------|--------|------------|---------|----------------------------------------------------------------------------------|
| ⭐ Orch    | ✅      | ✅          | —       | 모든 Decision Gate = P1. Risk 감지 = P2                                              |
| Monitor-A | —      | ✅          | —       | 탐지 전용. P2 트리거 후 Orch에 전달                                                         |
| Back-A    | ✅      | ✅          | ✅       | DB 변경 = P1. 실행 중 Risk 감지 = P2. 코드 산출물 = P3                                                        |
| Front-A   | —      | —          | ✅       | 코드 생성 후 Human 검수 (P3)                                                            |
| Test-A    | —      | ✅          | ✅       | KPI 이상 = P2. Evaluation Report = P3                                              |
| Evol-A    | ✅      | —          | ✅       | Context 제안 제출 = P1. 제안서 검토 = P3                                                  |
| UIUX-A    | —      | —          | ✅       | 산출물 확정은 항상 P3 (Human 전담)                                                         |

# 5. ApprovalGate 코드 구현 기준

Phase 3 코드 구현 시 Cursor AI가 참조하는 ApprovalGate의 구현 표준이다.

## 5.1 DB 스키마 요구사항

| 테이블               | 패턴            | 필수 컬럼                                                                                                                                        |
|-------------------|---------------|----------------------------------------------------------------------------------------------------------------------------------------------|
| approval_requests | P1            | id, agent_code, action_type, payload, status(PENDING/APPROVED/REJECTED), requested_by, approver, requested_at, resolved_at, rejection_reason |
| review_requests   | P3            | id, agent_code, artifact_type, artifact_id, status(PENDING/CONFIRMED/REVISED/REJECTED), reviewer, created_at, reviewed_at, revision_note     |
| override_logs     | P2 / Override | id, triggered_by, trigger_reason, affected_agents, snapshot_ref, action_taken, reported_at, governance_notified                              |

## 5.2 Approval Gate 동작 규칙

| 상황            | 처리 방식                        | audit_logs 기록                                     |
|---------------|------------------------------|---------------------------------------------------|
| 승인 (APPROVED) | Agent 실행 재개 + 결과 정상 처리       | status=APPROVED, approver, approved_at            |
| 거부 (REJECTED) | Agent 실행 취소 + 거부 사유 저장 + 알림  | status=REJECTED, rejection_reason, rejected_by    |
| 타임아웃 P1 (24h) | 상위 승인자 자동 에스컬레이션 + Orch 알림   | status=ESCALATED, escalated_at, original_approver |
| 타임아웃 P3 (48h) | 리마인더 발송 → +24h 후 PM 에스컬레이션   | status=REMINDER_SENT, reminder_sent_at            |
| Override 발동   | 즉시 중단 + Snapshot 저장 + 전파     | event=OVERRIDE, triggered_by, affected_agents     |
| Audit Log 실패  | Agent 실행 차단 + 에러 알림 + 재시도 불가 | status=BLOCKED, reason=AUDIT_LOG_FAILURE          |

## 5.3  SLA (응답 시간 기준)

| 패턴              | SLA      | 타임아웃 조치        | 에스컬레이션 대상                            |
|-----------------|----------|----------------|--------------------------------------|
| P1 Pre-approval | 업무일 24시간 | 상위 승인자 자동 전달   | AI Architect → PM → Governance Board |
| P2 On-risk      | 1시간      | Orch 자동 에스컬레이션 | 즉시 PM / Business Owner               |
| P3 Post-review  | 업무일 48시간 | 리마인더 → PM 알림   | Front-H/Back-H → AI Architect → PM   |
| Override 응답     | 3초 (자동)  | 시스템 강제 중단      | 해당 없음 (자동 처리)                        |

# 6. 승인 (Approval)

| 구분                     | 내용   | 서명  | 날짜  |
|------------------------|------|-----|-----|
| 작성자                    |      |     |     |
| 검토자 / (AI Architect)   |      |     |     |
| 승인자 / (Business Owner) |      |     |     |
| 버전                     | v1.0 |     |     |
