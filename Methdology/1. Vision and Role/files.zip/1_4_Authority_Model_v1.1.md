---
title: 1.4 Authority Model
project: Standard Framework Project
phase: Phase 1. Vision & Role 정의
document_id: "1.4 Authority Model.docx"
version: v1.0
author: KY Song
classification: CONFIDENTIAL

The EAOS methodology defines a structured lifecycle for
Designing, deploying, and governing enterprise-grade AI systems
---
# Project: Standard Framework Project
## 1.4 Authority Model
### Phase: 1. Vision & Role 정의
#### [산출물 ID: 1.4 Authority Model.docx]
- WBS Task
- 1.4.1 프로젝트 Authority Level 공식 결정 (L1 확정)
- 1.4.2 Agent별 자율성 레벨 및 허용/금지 범위 정의
- 1.4.3 레벨 변경 조건 및 Escalation 규칙 정의
- 1.4.4 Authority Level 선정 체크리스트

| 문서 번호 | 1.4 Authority Model.docx   |
|-------|----------------------------|
| 버전    | v1.0                       |
| 작성일   | 2026                       |
| 작성자   | KY Song                    |
| 분류    | CONFIDENTIAL               |
| 적용 대상 | Standard Framework 프로젝트 전체 |

# 1. 개요 및 결정 요약

본 문서는 Standard Framework 프로젝트에서 운영되는 모든 AI Agent의 자율성 수준(Authority Level)을 공식적으로 결정하고, 각 Agent별 허용 범위와 금지 사항을 명세한다.

> 💡 Authority Model은 Governance Charter(1.6)의 제3장을 프로젝트에 실제 적용한 결정서다. Charter가 '법률'이라면, Authority Model은 '이 프로젝트에서의 판결문'이다.

## 1.1 프로젝트 Authority Level 결정

> ⚠️  본 프로젝트의 공식 Authority Level은 L1 (추천 수준)으로 결정한다.

| 항목                | 결정 내용                                    |
|-------------------|------------------------------------------|
| Authority Level   | L1 — 추천 수준 (AI 추천, 최종 결정은 Human 승인 필수)   |
| Risk Level        | HIGH — 공공기관 적용, 재무·법적 영향 가능              |
| 프로젝트 유형           | DesignRecommendation — 설계 표준 및 공통 모듈 제공  |
| Human-in-the-Loop | 필수 — 모든 Decision Gate에서 Human 승인         |
| 자동 실행             | 불가 — L2 승인 전까지 자동 실행 코드 배포 금지            |
| Audit Log         | 필수 — 모든 Agent 실행 결과 audit_logs 기록 의무     |
| Drift 모니터링        | Monitor-A가 담당 — KPI Threshold 초과 시 즉시 알림 |
| 승인 주체             | Business Owner (L1 기준)                   |
| 결정일               | 2026                                     |
| 다음 검토일            | Phase 2 완료 시 또는 6개월 후 중 빠른 시점            |

## 1.2 Agent별 Authority Level 요약

| Agent     | 역할           | Level | Risk   | 자동 실행 | Human Gate                 |
|-----------|--------------|-------|--------|-------|----------------------------|
| ⭐ Orch    | Orchestrator | L1    | HIGH   | 불가    | 모든 Decision Gate           |
| Monitor-A | Monitoring   | L0    | LOW    | 불가    | Incident 대응 결정             |
| Back-A    | Backend      | L1    | HIGH   | 불가    | DB 변경 / 배포 승인              |
| Front-A   | Frontend     | L1    | MEDIUM | 불가    | 코드 리뷰 / 배포 승인              |
| Test-A    | Test & QA    | L1    | MEDIUM | 불가    | Evaluation Report 확정       |
| Evol-A    | Evolution    | L1    | HIGH   | 불가    | Context 수정 / Governance 승인 |
| UIUX-A    | UIUX Design  | L1    | MEDIUM | 불가    | 최종 산출물 확정                  |

# 2. Agent별 상세 Authority Model

> 💡 각 Agent 카드는 허용 범위(녹색), 금지 사항(빨간색), Human Gate, 레벨 변경 조건을 포함한다.

### ⭐ Orch — Orchestrator Agent

**Authority: L1** | **Risk: HIGH**

| 선정 근거      | 전체 Workflow 조정 및 Escalation 판단 수행. 모든 Decision Gate에서 Human 승인 필수. 자동 실행 권한 없음.                   |
|------------|---------------------------------------------------------------------------------------------------|
| 자동 실행      | 불가 — Human 승인 필수                                                                                   |
| Human Gate | 모든 Decision Gate                                                                                  |
| 허용 범위      | ✓  Workflow 흐름 조정 / ✓  Escalation 판단 및 이관 / ✓  Agent 실행 중단 (Risk CRITICAL 시) / ✓  Context 로드 및 조회 |
| 금지 사항      | ✗  전략 해석 또는 변경 / ✗  Context 직접 수정 / ✗  자동 권한 상승 / ✗  Human 승인 없는 외부 실행                            |
| 레벨 변경 조건   | L2 승인 시 — 반복 패턴 검증된 조건부 자동 Workflow에 한해 Governance Board 승인                                       |

### Monitor-A — Monitoring Agent

**Authority: L0** | **Risk: LOW**

| 선정 근거      | KPI 감시 및 이상 탐지만 수행. 실행 권한 없음. 탐지 결과를 Human 또는 Orchestrator에 통보만 함.               |
|------------|----------------------------------------------------------------------------------|
| 자동 실행      | 불가 — Human 승인 필수                                                                 |
| Human Gate | Incident 대응 결정                                                                   |
| 허용 범위      | ✓  KPI 실시간 모니터링 / ✓  Drift 자동 탐지 / ✓  Incident 알림 발송 / ✓  audit_logs 조회 및 보고서 생성 |
| 금지 사항      | ✗  시스템 직접 변경 / ✗  Agent 강제 중단 (Orchestrator 경유 필수) / ✗  Context 수정               |
| 레벨 변경 조건   | L1 승인 시 — 감사 보고서 자동 생성 기능 추가 시 Business Owner 승인                                 |

### Back-A — Backend Agent

**Authority: L1** | **Risk: HIGH**

| 선정 근거      | Python Agent 코드 및 API 생성. DB 변경 포함 HIGH 리스크. 모든 실행에 Audit Log 필수. 배포 전 Human 검수 필수.             |
|------------|-------------------------------------------------------------------------------------------------|
| 자동 실행      | 불가 — Human 승인 필수                                                                                |
| Human Gate | DB 변경 / 외부 API 호출 / 배포 승인                                                                       |
| 허용 범위      | ✓  BaseAgent 상속 코드 생성 / ✓  FastAPI 엔드포인트 생성 / ✓  DB 쿼리 작성 (트랜잭션 포함) / ✓  Audit Log INSERT 코드 생성 |
| 금지 사항      | ✗  Audit Log 없는 실행 코드 / ✗  트랜잭션 없는 DB 변경 / ✗  API Key 하드코딩 / ✗  Human 승인 없는 외부 API 호출           |
| 레벨 변경 조건   | L2 승인 시 — 반복 검증된 CRUD 패턴에 한해 Governance Board 승인. Audit Log 조건 유지 필수.                           |

### Front-A — Frontend Agent

**Authority: L1** | **Risk: MEDIUM**

| 선정 근거      | React 컴포넌트 코드 생성 및 UI 자동화 수행. 배포 코드 최종 확정은 Human 검수 필수. 직접 배포 권한 없음.                        |
|------------|---------------------------------------------------------------------------------------------|
| 자동 실행      | 불가 — Human 승인 필수                                                                            |
| Human Gate | 코드 리뷰 및 배포 승인                                                                               |
| 허용 범위      | ✓  React 컴포넌트 코드 생성 / ✓  타입 정의 생성 / ✓  useAgent 훅 경유 API 호출 코드 생성 / ✓  ApprovalGate 컴포넌트 생성 |
| 금지 사항      | ✗  any 타입 사용 / ✗  직접 API 호출 (useAgent 훅 경유 필수) / ✗  배포 파이프라인 직접 실행                          |
| 레벨 변경 조건   | 해당 없음 — 코드 최종 확정은 항상 Human 검수                                                               |

### Test-A — Test Agent

**Authority: L1** | **Risk: MEDIUM**

| 선정 근거      | 테스트 자동 실행 및 KPI 측정 수행. Evaluation Report 최종 확정은 Human. 재배포 요청 권한 없음.                        |
|------------|---------------------------------------------------------------------------------------------|
| 자동 실행      | 불가 — Human 승인 필수                                                                            |
| Human Gate | Evaluation Report 확정 / 재배포 승인                                                               |
| 허용 범위      | ✓  Test Scenario 자동 실행 / ✓  KPI 측정 및 집계 / ✓  Drift 탐지 및 Incident 알림 / ✓  trajectory_logs 기록 |
| 금지 사항      | ✗  회귀 테스트 없이 재배포 요청 / ✗  Evaluation Report 없는 배포 승인 요청 / ✗  실패 케이스 미기록                      |
| 레벨 변경 조건   | L0 하향 가능 — 단순 KPI 집계/모니터링에 한해 Human 승인 없이 자동 실행 허용 검토 가능                                    |

### Evol-A — Evolution Agent

**Authority: L1** | **Risk: HIGH**

| 선정 근거      | Context 수정 제안 생성. HIGH 리스크 — Context 변경은 전체 시스템에 영향. 제안만 가능, 직접 적용 절대 금지.    |
|------------|------------------------------------------------------------------------------|
| 자동 실행      | 불가 — Human 승인 필수                                                             |
| Human Gate | Context 수정 제안 검토 / Governance Board 승인                                       |
| 허용 범위      | ✓  로그 분석 및 패턴 탐지 / ✓  Context 수정 제안서 작성 / ✓  Regression Test 결과 분석           |
| 금지 사항      | ✗  Context 직접 수정 (Governance 승인 없이) / ✗  재배포 직접 트리거 / ✗  승인 없는 Constraint 변경 |
| 레벨 변경 조건   | 해당 없음 — Context 변경은 항상 Governance Board 승인 필수. 레벨 상향 불가.                     |

### UIUX-A — UIUX Agent

**Authority: L1** | **Risk: MEDIUM**

| 선정 근거      | Persona 분석 보조 및 시나리오 초안 생성만 수행. 최종 확정은 Human 전담. 사용자 직접 영향 없음.          |
|------------|-------------------------------------------------------------------------|
| 자동 실행      | 불가 — Human 승인 필수                                                        |
| Human Gate | 최종 산출물 확정 시                                                             |
| 허용 범위      | ✓  Persona 분석 보조 / ✓  Conversation Flow 초안 생성 / ✓  Usage Scenario 초안 생성 |
| 금지 사항      | ✗  최종 Persona 직접 확정 / ✗  Context 직접 수정 / ✗  사용자 데이터 직접 접근               |
| 레벨 변경 조건   | 해당 없음 — UX 설계 최종 결정은 항상 Human 전담                                        |

# 3. Authority Level 선정 체크리스트

신규 Agent 추가 또는 기존 Agent 레벨 변경 시 아래 체크리스트를 반드시 수행한다.

| No. | 확인 항목                    | Yes인 경우                        | No인 경우                       |
|-----|--------------------------|--------------------------------|------------------------------|
| 1   | 자동 실행이 포함되는가?            | L2 이상 → Governance Board 승인 필수 | L1 이하로 유지 가능                 |
| 2   | 법적/재무적 영향이 존재하는가?        | Risk Level HIGH 이상으로 상향        | MEDIUM 이하 가능                 |
| 3   | Human Override가 항상 가능한가? | 정상 — 설계 적합                     | 설계 재검토 필수. Override 불가 배포 금지 |
| 4   | Audit Log가 반드시 기록되는가?    | 정상 — 배포 가능                     | 배포 차단. Audit Log 구현 후 재심사    |
| 5   | Drift 모니터링 체계가 존재하는가?    | 정상 — Monitor-A 연동 확인           | Monitor-A 연동 후 배포 허용         |
| 6   | Context를 직접 수정할 수 있는가?   | Governance Board 특별 승인 필수      | 정상 — Evolution Agent 경유로 설계  |

# 4. Escalation 규칙

| 트리거              | Escalation 경로                                                          |
|------------------|------------------------------------------------------------------------|
| Risk CRITICAL 감지 | 즉시 실행 중단 → Orchestrator → Business Owner → 긴급 대응                       |
| Risk HIGH / 미승인  | Human 승인 게이트 → 미승인 시 중단 → 사유 Audit Log 기록                              |
| Scope 초과 실행 시도   | 즉시 중단 → Orchestrator 에스컬레이션 → 예외 승인 절차 (최대 90일)                        |
| Audit Log 누락 탐지  | 배포 차단 → Audit Log 구현 의무 → Back-A 재작업 후 재심사                             |
| Drift 감지         | Monitor-A 알림 → Orchestrator → AI Architect → Evol-A 제안 → Governance 승인 |
| Context 무단 수정 시도 | 즉시 차단 → Governance Board 보고 → Context 복원 → 보안 감사                       |

# 5. Authority Level 변경 절차

> 💡 현재 전 Agent L1 기준. L2 이상으로의 변경은 아래 절차를 반드시 준수한다.

| 단계  | 활동              | 내용                              | 담당                         |
|-----|-----------------|---------------------------------|----------------------------|
| 1   | 변경 제안           | 레벨 변경 대상 Agent 및 사유 문서화         | AI Architect               |
| 2   | Risk 재평가        | 변경 후 리스크 영향 범위 분석               | Compliance Officer         |
| 3   | 체크리스트           | 3장 Authority Level 선정 체크리스트 재수행 | AI Architect + QA          |
| 4   | Governance 승인   | Governance Board 검토 및 승인        | Governance Board           |
| 5   | 문서 업데이트         | 본 문서 + governance.json 버전 업데이트  | AI Architect               |
| 6   | Regression Test | 변경 사항에 대한 회귀 테스트 수행             | Test Agent                 |
| 7   | 재배포             | 승인 완료 후 배포                      | Back-H (Backend Developer) |

# 6. 승인 (Approval)

| 구분                     | 내용   | 서명  | 날짜  |
|------------------------|------|-----|-----|
| 작성자                    |      |     |     |
| 검토자 / (AI Architect)   |      |     |     |
| 승인자 / (Business Owner) |      |     |     |
| 버전                     | v1.0 |     |     |
